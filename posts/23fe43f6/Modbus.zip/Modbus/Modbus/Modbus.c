#include "Modbus.h"

extern TIM_HandleTypeDef  htim2;
extern UART_HandleTypeDef huart3;

#define RX_BUFFER_SIZE 256 //接收缓冲区大小
#define Frame_Timeout_ms 4 //帧间隔超时时间，单位为毫秒

uint8_t rx_buffer[RX_BUFFER_SIZE]; //接收缓冲区
uint8_t rx_index = 0; //接收缓冲区索引
uint32_t last_rx_time = 0; //上次接收数据的时间戳

static uint8_t *current_buffer = NULL; //当前数据缓冲区指针，用于存储接收到的数据

//Modbus初始化函数
void Modbus_Init(void)
{
    HAL_TIM_Base_Start_IT(&htim2); //启动定时器2中断
    HAL_UART_Receive_IT(&huart3, &rx_buffer[rx_index], 1); //启动串口3接收中断
}

//Modbus接收数据回调函数
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART3) //检查是否为串口3
    {
        //检查缓冲区是否已满
        if (rx_index < RX_BUFFER_SIZE - 1)
        {
            last_rx_time = HAL_GetTick(); //更新接收时间戳
            rx_index++; //接收到的数据存储到缓冲区，索引加1
            HAL_UART_Receive_IT(&huart3, &rx_buffer[rx_index], 1); //继续接收下一个字节
        }
        else
        {
            //缓冲区已满，丢弃数据并重置索引
            rx_index = 0;
            HAL_UART_Receive_IT(&huart3, &rx_buffer[rx_index], 1); //重新开始接收
        }
    }
}

//Modbus CRC16校验计算函数
uint16_t Modbus_CRC16(uint8_t *data, uint16_t length)
{
    uint16_t crc = 0xFFFF; //初始化CRC寄存器
    for (uint16_t i = 0; i < length; i++)
    {
        crc ^= data[i]; //将数据与CRC寄存器进行异或运算
        for (uint8_t j = 0; j < 8; j++)
        {
            if (crc & 0x0001) //检查最低位是否为1
            {
                crc >>= 1; //右移一位
                crc ^= 0xA001; //与多项式进行异或运算
            }
            else
            {
                crc >>= 1; //右移一位
            }
        }
    }
    return crc; //返回计算得到的CRC值
}

//Modbus发送数据函数
void Modbus_Send(uint8_t *data, uint16_t length)
{
    // 发送前：使能发送，禁止接收
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_SET);
    //通过串口3发送数据
    HAL_UART_Transmit(&huart3, data, length, HAL_MAX_DELAY); 
    //等待发送完成
    while (__HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC) == RESET);
    //等待发送完成标志位被置位
    HAL_Delay(10);
    // 发送后：禁止发送，使能接收
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_RESET);
}

//Modbus处理接收到的数据函数
void Modbus_Handle_Rx(uint8_t *data, uint8_t length)
{
    //crc校验
    uint16_t received_crc = (data[length - 1] << 8) | data[length - 2]; //接收到的CRC值
    uint16_t calculated_crc = Modbus_CRC16(data, length - 2);//计算得到的CRC值，排除最后两个字节的CRC
    if (received_crc != calculated_crc)
    {
        return; //CRC校验失败，丢弃数据
    }

    //解析从站返回的数据，根据功能码进行处理
    uint8_t slave_addr = data[0]; //从站地址
    uint8_t function_code = data[1]; //功能码
    
    if (function_code == 0x01)//功能码01处理
    {
        //解析字节数和线圈数量
        uint8_t byte_count = data[2]; //字节计数
        memcpy(current_buffer, &data[3], byte_count); //将接收到的数据复制到当前缓冲区
    }
    else if (function_code == 0x03)//功能码03处理
    {
        //解析字节数和寄存器数量
        uint8_t byte_count = data[2]; //字节计数
        memcpy(current_buffer, &data[3], byte_count); //将接收到的数据复制到当前缓冲区
    }
    else if(function_code == 0x05)
    {
        //检查响应帧长度（固定6字节数据+2字节CRC）
        if (length != 8)
        {
            return;
        }
        //解析线圈地址和线圈值
        uint16_t coil_addr = (data[2] << 8) | data[3]; //线圈地址
        uint16_t coil_value = (data[4] << 8) | data[5]; //线圈值
    }
    else if(function_code == 0x06)
    {
        //检查响应帧长度（固定6字节数据+2字节CRC）
        if (length != 8)
        {
            return;
        }
        //解析寄存器地址和寄存器值
        uint16_t reg_addr = (data[2] << 8) | data[3]; //寄存器地址
        uint16_t reg_value = (data[4] << 8) | data[5]; //寄存器值
    }
    else if(function_code == 0x0F)
    {
        //检查响应帧长度（固定6字节数据+2字节CRC）
        if (length != 8)
        {
            return;
        }
        //解析起始线圈地址和线圈数量
        uint16_t start_addr = (data[2] << 8) | data[3]; //起始线圈地址
        uint16_t num_coils = (data[4] << 8) | data[5]; //线圈数量
    }
    else if(function_code == 0x10)
    {
        //检查响应帧长度（固定6字节数据+2字节CRC）
        if (length != 8)
        {
            return;
        }
        //解析起始寄存器地址和寄存器数量
        uint16_t start_addr = (data[2] << 8) | data[3]; //起始寄存器地址
        uint16_t num_regs = (data[4] << 8) | data[5]; //寄存器数量
    }
    else if(function_code >= 0x80)
    {
        //异常响应处理
        uint8_t error_code = data[2]; //异常码
    }
    else
    {
        ;
    }
}

//Modbus定时器中断回调函数
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM2)
    {
        //检查是否有数据接收，并且距离上次接收时间超过帧间隔超时时间
        if (HAL_GetTick() - last_rx_time >= Frame_Timeout_ms)
        {
            //处理接收到的数据
            if (rx_index > 0)
            {
                Modbus_Handle_Rx(rx_buffer, rx_index); //调用处理函数，传入接收缓冲区和数据长度
                //处理完数据后，重置接收缓冲区索引
                rx_index = 0;
            }
        }
    }
}

//01功能码，Modbus读取线圈状态
void Modbus_Read_01(uint8_t slave_addr, uint16_t start_addr, uint16_t num_coils, uint8_t *user_buffer)
{
    uint8_t TX_Frame[8];
    uint16_t crc;

    current_buffer = user_buffer; //设置当前数据缓冲区，将user_buffer指针传递给current_buffer，以便在接收数据时将数据存储到正确的缓冲区中
    //1.构建Modbus RTU请求帧
    TX_Frame[0] = slave_addr; //从机地址
    TX_Frame[1] = 0x01; //功能码
    TX_Frame[2] = (start_addr >> 8) & 0xFF; //起始地址高字节
    TX_Frame[3] = start_addr & 0xFF; //起始地址低字节
    TX_Frame[4] = (num_coils >> 8) & 0xFF; //线圈数量高字节
    TX_Frame[5] = num_coils & 0xFF; //线圈数量低字节
    //2.计算CRC校验码
    crc = Modbus_CRC16(TX_Frame, 6); //计算CRC校验码
    TX_Frame[6] = crc & 0xFF; //CRC低字节
    TX_Frame[7] = (crc >> 8) & 0xFF; //CRC高字节
    //3.发送请求帧
    Modbus_Send(TX_Frame, 8); //发送数据帧
}

//03功能码，Modbus读取保持寄存器
void Modbus_Read_03(uint8_t slave_addr, uint16_t start_addr, uint16_t num_regs,uint8_t *user_buffer)
{
    uint8_t TX_Frame[8];
    uint16_t crc;

    current_buffer = user_buffer; //设置当前数据缓冲区，将user_buffer指针传递给current_buffer，以便在接收数据时将数据存储到正确的缓冲区中
    //1.构建Modbus RTU请求帧
    TX_Frame[0] = slave_addr; //从机地址
    TX_Frame[1] = 0x03; //功能码
    TX_Frame[2] = (start_addr >> 8) & 0xFF; //起始地址高字节
    TX_Frame[3] = start_addr & 0xFF; //起始地址低字节
    TX_Frame[4] = (num_regs >> 8) & 0xFF; //寄存器数量高字节
    TX_Frame[5] = num_regs & 0xFF; //寄存器数量低字节
    //2.计算CRC校验码
    crc = Modbus_CRC16(TX_Frame, 6); //计算CRC校验码
    TX_Frame[6] = crc & 0xFF; //CRC低字节
    TX_Frame[7] = (crc >> 8) & 0xFF; //CRC高字节
    //3.发送请求帧
    Modbus_Send(TX_Frame, 8); //发送数据帧
}


//05功能码，Modbus写单个线圈
void Modbus_Write_05(uint8_t slave_addr, uint16_t coil_addr, uint16_t coil_value)
{
    uint8_t TX_Frame[8];
    uint16_t crc;

    //1.构建Modbus RTU请求帧
    TX_Frame[0] = slave_addr; //从机地址
    TX_Frame[1] = 0x05; //功能码
    TX_Frame[2] = (coil_addr >> 8) & 0xFF; //线圈地址高字节
    TX_Frame[3] = coil_addr & 0xFF; //线圈地址低字节
    TX_Frame[4] = (coil_value == 0) ? 0x00 : 0xFF; //线圈值，0x00表示关闭，0xFF表示开启
    TX_Frame[5] = 0x00; //线圈值低字节，固定为0x00
    //2.计算CRC校验码
    crc = Modbus_CRC16(TX_Frame, 6); //计算CRC校验码
    TX_Frame[6] = crc & 0xFF; //CRC低字节
    TX_Frame[7] = (crc >> 8) & 0xFF; //CRC高字节
    //3.发送请求帧
    Modbus_Send(TX_Frame, 8); //发送数据帧
}

//06功能码，Modbus写单个保持寄存器
void Modbus_Write_06(uint8_t slave_addr, uint16_t reg_addr, uint16_t reg_value)
{
    uint8_t TX_Frame[8];
    uint16_t crc;

    //1.构建Modbus RTU请求帧
    TX_Frame[0] = slave_addr; //从机地址
    TX_Frame[1] = 0x06; //功能码
    TX_Frame[2] = (reg_addr >> 8) & 0xFF; //寄存器地址高字节
    TX_Frame[3] = reg_addr & 0xFF; //寄存器地址低字节
    TX_Frame[4] = (reg_value >> 8) & 0xFF; //寄存器值高字节
    TX_Frame[5] = reg_value & 0xFF; //寄存器值低字节
    //2.计算CRC校验码
    crc = Modbus_CRC16(TX_Frame, 6); //计算CRC校验码
    TX_Frame[6] = crc & 0xFF; //CRC低字节
    TX_Frame[7] = (crc >> 8) & 0xFF; //CRC高字节
    //3.发送请求帧
    Modbus_Send(TX_Frame, 8); //发送数据帧
}

//15功能码，Modbus写多个线圈
void Modbus_Write_15(uint8_t slave_addr, uint16_t start_addr, uint16_t num_coils_regs, uint8_t *coil_values)
{
    uint8_t TX_Frame[9 + num_coils_regs]; //根据需要调整缓冲区大小
    uint16_t crc;

    //1.构建Modbus RTU请求帧
    TX_Frame[0] = slave_addr; //从机地址
    TX_Frame[1] = 0x0F; //功能码
    TX_Frame[2] = (start_addr >> 8) & 0xFF; //起始地址高字节
    TX_Frame[3] = start_addr & 0xFF; //起始地址低字节
    TX_Frame[4] = (num_coils_regs >> 8) & 0xFF; //线圈数量高字节
    TX_Frame[5] = num_coils_regs & 0xFF; //线圈数量低字节
    TX_Frame[6] = (num_coils_regs + 7) / 8; //字节计数

    //将线圈值填充到请求帧中
    for (uint16_t i = 0; i < (num_coils_regs + 7) / 8; i++)
    {
        TX_Frame[7 + i] = coil_values[i]; //将线圈值复制到请求帧中
    }

    //2.计算CRC校验码
    crc = Modbus_CRC16(TX_Frame, 7 + (num_coils_regs + 7) / 8); //计算CRC校验码
    TX_Frame[7 + (num_coils_regs + 7) / 8] = crc & 0xFF; //CRC低字节
    TX_Frame[8 + (num_coils_regs + 7) / 8] = (crc >> 8) & 0xFF; //CRC高字节

    //3.发送请求帧
    Modbus_Send(TX_Frame, 9 + (num_coils_regs + 7) / 8); //发送数据帧      
}

//16功能码，Modbus写多个保持寄存器
void Modbus_Write_16(uint8_t slave_addr, uint16_t start_addr, uint16_t num_regs, uint16_t *reg_values)
{
    uint8_t TX_Frame[9+2*num_regs]; //根据需要调整缓冲区大小，长度为9+2*寄存器数量
    uint16_t crc;

    //1.构建Modbus RTU请求帧
    TX_Frame[0] = slave_addr; //从机地址
    TX_Frame[1] = 0x10; //功能码
    TX_Frame[2] = (start_addr >> 8) & 0xFF; //起始地址高字节
    TX_Frame[3] = start_addr & 0xFF; //起始地址低字节
    TX_Frame[4] = (num_regs >> 8) & 0xFF; //寄存器数量高字节
    TX_Frame[5] = num_regs & 0xFF; //寄存器数量低字节
    TX_Frame[6] = num_regs * 2; //字节计数，因为每个寄存器占用2个字节

    //将寄存器值填充到请求帧中
    for (uint16_t i = 0; i < num_regs; i++)
    {
        TX_Frame[7 + i * 2] = (reg_values[i] >> 8) & 0xFF; //寄存器值高字节
        TX_Frame[8 + i * 2] = reg_values[i] & 0xFF; //寄存器值低字节
    }

    //2.计算CRC校验码
    crc = Modbus_CRC16(TX_Frame, 7 + 2 * num_regs); //计算CRC校验码
    TX_Frame[7 + 2 * num_regs] = crc & 0xFF; //CRC低字节
    TX_Frame[8 + 2 * num_regs] = (crc >> 8) & 0xFF; //CRC高字节

    //3.发送请求帧
    Modbus_Send(TX_Frame, 9 + 2 * num_regs); //发送数据帧      
}

int16_t Modbus_MergeHighLow(uint8_t high, uint8_t low)
{
    return ((high << 8) | low); //将高字节和低字节合并为一个16位有符号整数
}
