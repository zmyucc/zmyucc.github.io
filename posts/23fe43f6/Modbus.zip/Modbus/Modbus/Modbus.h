#ifndef __MODBUS_H
#define __MODBUS_H

#include "main.h"
#include "string.h"

void Modbus_Init(void);
void Modbus_Read_01(uint8_t slave_addr, uint16_t start_addr, uint16_t num_coils, uint8_t *user_buffer);
void Modbus_Read_03(uint8_t slave_addr, uint16_t start_addr, uint16_t num_regs,uint8_t *user_buffer);
void Modbus_Write_05(uint8_t slave_addr, uint16_t coil_addr, uint16_t coil_value);
void Modbus_Write_06(uint8_t slave_addr, uint16_t reg_addr, uint16_t reg_value);
void Modbus_Write_15(uint8_t slave_addr, uint16_t start_addr, uint16_t num_coils_regs, uint8_t *coil_values);
void Modbus_Write_16(uint8_t slave_addr, uint16_t start_addr, uint16_t num_regs, uint16_t *reg_values); 
int16_t Modbus_MergeHighLow(uint8_t high, uint8_t low); 

#endif

