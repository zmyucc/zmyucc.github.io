#ifndef __MODBUS_SLAVE_H
#define __MODBUS_SLAVE_H

#include <stdint.h>

extern uint16_t Modbus_Register[5000];
extern uint16_t Modbus_Coil[1000];

void Modbus_Slave_Init(void);
uint16_t Modbus_CRC16(uint8_t *data, uint16_t length);
void Modbus_Handle_Rx(uint8_t *data, uint8_t length);
void Modbus_Send(uint8_t *data, uint16_t length);
void Modbus_Slave_01(uint16_t Num_Coils,uint16_t Start_Coils);
void Modbus_Slave_03(uint16_t Num_Regs,uint16_t Start_Regs);
void Modbus_Slave_05(uint16_t Coil_Address, uint8_t Coil_Value);
void Modbus_Slave_06(uint16_t Reg_Address, uint16_t Reg_Value);
void Modbus_Slave_15(uint16_t Coil_Address, uint16_t Num_Coils);
void Modbus_Slave_16(uint16_t Reg_Address, uint16_t Num_Regs, uint16_t *Reg_Values);
#endif

