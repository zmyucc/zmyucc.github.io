#include "Modbus_Slave.h"
#include "main.h"
#include <stdint.h>
#include "OLED.h"

extern UART_HandleTypeDef huart3;
extern TIM_HandleTypeDef htim2;

#define Modbus_Slave_ID 0x02 //Modbus RTU从站地址
#define RX_BUFFER_SIZE 256 //接收缓冲区大小
#define Frame_Timeout_ms 4 //帧间隔超时时间，单位为毫秒
uint8_t rx_buffer[RX_BUFFER_SIZE]; //接收缓冲区
uint8_t rx_index = 0; //接收缓冲区索引
uint32_t last_rx_time = 0; //上次接收数据的时间戳
uint16_t Modbus_Register[5000];//寄存器数组，存储Modbus寄存器数据
uint16_t Modbus_Coil[1000];//线圈数组，存储Modbus线圈数据


//Modbus定时器中断回调函数
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM2)
    {
        if (HAL_GetTick() - last_rx_time >= Frame_Timeout_ms)
        {
            if (rx_index > 0)
            {
                // 1. 先关闭正在进行的接收中断
                HAL_UART_AbortReceive_IT(&huart3);
                // 2. 处理已接收的帧
                Modbus_Handle_Rx(rx_buffer, rx_index);
                // 3. 重置索引
                rx_index = 0;
                // 4. 重新启动接收中断，从缓冲区头部开始
                HAL_UART_Receive_IT(&huart3, &rx_buffer[0], 1);
            }
        }
    }
}

//Modbus接收数据回调函数
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART3) //检查是否为串口3
    {
        //检查缓冲区是否已满
        if (rx_index < RX_BUFFER_SIZE - 1)
        {
            last_rx_time = HAL_GetTick(); //更新接收时间戳
            rx_index++; //接收到的数据存储到缓冲区，索引加1
            HAL_UART_Receive_IT(&huart3, &rx_buffer[rx_index], 1); //继续接收下一个字节
        }
        else
        {
            //缓冲区已满，丢弃数据并重置索引
            rx_index = 0;
            HAL_UART_Receive_IT(&huart3, &rx_buffer[rx_index], 1); //重新开始接收
        }
    }
}


void Modbus_Slave_Init(void)
{
    HAL_TIM_Base_Start_IT(&htim2);
    HAL_UART_Receive_IT(&huart3, &rx_buffer[0], 1);
}

//Modbus发送数据函数
void Modbus_Send(uint8_t *data, uint16_t length)
{
    // 发送前：使能发送，禁止接收
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_SET);
    //通过串口3发送数据
    HAL_UART_Transmit(&huart3, data, length, HAL_MAX_DELAY); 
    //等待发送完成
    while (__HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC) == RESET);
    // 发送后：禁止发送，使能接收
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_RESET);
}


//接收数据处理函数
void Modbus_Handle_Rx(uint8_t *data, uint8_t length)
{
    //crc校验
    uint16_t received_crc = (data[length - 1] << 8) | data[length - 2]; //接收到的CRC值
    uint16_t calculated_crc = Modbus_CRC16(data, length - 2);//计算得到的CRC值，排除最后两个字节的CRC
    if (received_crc != calculated_crc)
    {
        return; //CRC校验失败，丢弃数据
    }
    if(data[0] != Modbus_Slave_ID)//检查从站地址是否匹配，如果不匹配则丢弃数据
    {
        return; 
    }
    //解析从站返回的数据，根据功能码进行处理
    uint8_t function_code = data[1]; //功能码
    //根据功能码不同，进行不同的处理
    if (function_code == 0x01) //功能码01处理
    {
        //解析地址
        uint16_t start_address = (data[2] << 8) | data[3]; //起始地址
        //解析线圈数量
        uint16_t num_coils = (data[4] << 8) | data[5]; //线圈数量
        //调用01功能码处理函数
        Modbus_Slave_01(num_coils, start_address);
    }
    else if (function_code == 0x03)//功能码03处理
    {
        //解析地址
        uint16_t start_address = (data[2] << 8) | data[3]; //起始地址
        //解析寄存器数量
        uint16_t num_registers = (data[4] << 8) | data[5]; //寄存器数量
        //调用03功能码处理函数
        Modbus_Slave_03(num_registers, start_address);
    }
    else if(function_code == 0x05) //功能码05处理
    {
        //解析地址
        uint16_t coil_address = (data[2] << 8) | data[3]; //线圈地址
        //解析线圈值
        uint8_t coil_value = (data[4] == 0xFF) ? 1 : 0; //线圈值，0xFF表示ON，0x00表示OFF
        //更新线圈状态
        if (coil_value)
        {
            Modbus_Coil[coil_address / 16] |= (1 << (coil_address % 16)); //设置对应位为1
        }
        else
        {
            Modbus_Coil[coil_address / 16] &= ~(1 << (coil_address % 16)); //设置对应位为0
        }
        //调用05功能码处理函数
        Modbus_Slave_05(coil_address, coil_value);
    }
    else if (function_code == 0x06) //功能码06处理
    {
        //解析地址
        uint16_t reg_address = (data[2] << 8) | data[3]; //寄存器地址
        //解析寄存器值
        uint16_t reg_value = (data[4] << 8) | data[5]; //寄存器值
        //更新寄存器值
        Modbus_Register[reg_address] = reg_value;
        //调用06功能码处理函数
        Modbus_Slave_06(reg_address, reg_value);
    }
    else if (function_code == 0x0F) //功能码15处理
    {
        //解析地址
        uint16_t start_address = (data[2] << 8) | data[3]; //起始地址
        //解析线圈数量
        uint16_t num_coils = (data[4] << 8) | data[5]; //线圈数量
        //更新线圈状态
        for (uint16_t i = 0; i < num_coils; i++)
        {
            uint16_t coil_index = start_address + i;      // 绝对线圈地址
            uint16_t word_index = coil_index / 16;       // 在Modbus_Coil数组中的索引（第几个uint16_t）
            uint8_t bit_position = coil_index % 16;      // 在该uint16_t中的位位置（0-15）

            // 检查数据区中对应的位是否为ON
            if (data[7 + i / 8] & (1 << (i % 8)))
            {
                Modbus_Coil[word_index] |= (1 << bit_position); //设置对应位为1
            }
            else
            {
                Modbus_Coil[word_index] &= ~(1 << bit_position); //设置对应位为0
            }
        }
        Modbus_Slave_15(start_address, num_coils);
    }
    else if (function_code == 0x10) //功能码16处理
    {
        //解析地址
        uint16_t reg_address = (data[2] << 8) | data[3]; //寄存器地址
        //解析寄存器数量
        uint16_t num_registers = (data[4] << 8) | data[5]; //寄存器数量
        //更新寄存器值
        for (uint16_t i = 0; i < num_registers; i++)
        {
            Modbus_Register[reg_address + i] = (data[7 + i * 2] << 8) | data[8 + i * 2]; //更新寄存器值
        }
        //调用16功能码处理函数
        Modbus_Slave_16(reg_address, num_registers, (uint16_t *)&data[7]);
    }
}

//01功能码，Modbus读取线圈状态
void Modbus_Slave_01(uint16_t Num_Coils,uint16_t Start_Coils)
{
    uint8_t TX_Frame[5 + (Num_Coils + 7) / 8]; //根据需要调整缓冲区大小
    uint16_t crc;
    uint8_t byte_count = (Num_Coils + 7) / 8;

    TX_Frame[0] = Modbus_Slave_ID; //Modbus RTU从站地址
    TX_Frame[1] = 0x01; //功能码01
    TX_Frame[2] = (Num_Coils + 7) / 8; //字节数

    // 初始化数据区为0
    for (uint8_t i = 0; i < byte_count; i++)
    {
        TX_Frame[3 + i] = 0;
    }

     // 填充线圈状态，每个uint16_t存储16个线圈
    for (uint16_t i = 0; i < Num_Coils; i++)
    {
        uint16_t coil_index = Start_Coils + i;      // 绝对线圈地址
        uint16_t word_index = coil_index / 16;       // 在Modbus_Coil数组中的索引（第几个uint16_t）
        uint8_t bit_position = coil_index % 16;      // 在该uint16_t中的位位置（0-15）

        // 检查该线圈是否为ON
        if (Modbus_Coil[word_index] & (1 << bit_position))
        {
            // 在响应帧中设置对应位
            TX_Frame[3 + i / 8] |= (1 << (i % 8));
        }
    }

    crc = Modbus_CRC16(TX_Frame, 3 + (Num_Coils + 7) / 8); //计算CRC校验码
    TX_Frame[3 + (Num_Coils + 7) / 8] = crc & 0xFF; //CRC低字节
    TX_Frame[4 + (Num_Coils + 7) / 8] = (crc >> 8) & 0xFF; //CRC高字节

    Modbus_Send(TX_Frame, 5 + (Num_Coils + 7) / 8);
}

//03功能码，Modbus读取保持寄存器
void Modbus_Slave_03(uint16_t Num_Regs,uint16_t Start_Regs)
{
    uint8_t TX_Frame[5 + Num_Regs * 2]; //根据需要调整缓冲区大小
    uint16_t crc;

    TX_Frame[0] = Modbus_Slave_ID;//Modbus RTU从站地址
    TX_Frame[1] = 0x03;
    TX_Frame[2] = Num_Regs * 2;
    for (uint16_t i = 0; i < Num_Regs; i++) 
    {
        TX_Frame[3 + i * 2] = (Modbus_Register[Start_Regs + i] >> 8) & 0xFF;
        TX_Frame[4 + i * 2] = Modbus_Register[Start_Regs + i] & 0xFF;
    }
    crc = Modbus_CRC16(TX_Frame, 3 + 2 * Num_Regs); //计算CRC校验码
    TX_Frame[3 + 2 * Num_Regs] = crc & 0xFF; //CRC低字节
    TX_Frame[4 + 2 * Num_Regs] = (crc >> 8) & 0xFF; //CRC高字节

    Modbus_Send(TX_Frame, 5 + 2 * Num_Regs);
}

//05功能码，Modbus写单个线圈
void Modbus_Slave_05(uint16_t Coil_Address, uint8_t Coil_Value)
{
    uint8_t TX_Frame[8]; //根据需要调整缓冲区大小
    uint16_t crc;

    TX_Frame[0] = Modbus_Slave_ID; //Modbus RTU从站地址
    TX_Frame[1] = 0x05;
    TX_Frame[2] = (Coil_Address >> 8) & 0xFF; //线圈地址高字节
    TX_Frame[3] = Coil_Address & 0xFF; //线圈地址低字节
    TX_Frame[4] = (Coil_Value == 0) ? 0x00 : 0xFF; //线圈值，0x00表示OFF，0xFF表示ON
    TX_Frame[5] = 0x00; //线圈值低字节，保持为0

    crc = Modbus_CRC16(TX_Frame, 6); //计算CRC校验码
    TX_Frame[6] = crc & 0xFF; //CRC低字节
    TX_Frame[7] = (crc >> 8) & 0xFF; //CRC高字节

    Modbus_Send(TX_Frame, 8);
}


//06功能码，Modbus写单个保持寄存器
void Modbus_Slave_06(uint16_t Reg_Address, uint16_t Reg_Value)
{
    uint8_t TX_Frame[8]; //根据需要调整缓冲区大小
    uint16_t crc;

    TX_Frame[0] = Modbus_Slave_ID;//Modbus RTU从站地址
    TX_Frame[1] = 0x06;
    TX_Frame[2] = (Reg_Address >> 8) & 0xFF; //寄存器地址高字节
    TX_Frame[3] = Reg_Address & 0xFF; //寄存器地址低字节
    TX_Frame[4] = (Reg_Value >> 8) & 0xFF; //寄存器值高字节
    TX_Frame[5] = Reg_Value & 0xFF; //寄存器值低字节

    crc = Modbus_CRC16(TX_Frame, 6); //计算CRC校验码
    TX_Frame[6] = crc & 0xFF; //CRC低字节
    TX_Frame[7] = (crc >> 8) & 0xFF; //CRC高字节

    Modbus_Send(TX_Frame, 8);
}

//15功能码，Modbus写多个线圈
void Modbus_Slave_15(uint16_t Coil_Address, uint16_t Num_Coils)
{
    uint8_t TX_Frame[8]; //根据需要调整缓冲区大小
    uint16_t crc;

    TX_Frame[0] = Modbus_Slave_ID; //Modbus RTU从站地址
    TX_Frame[1] = 0x0F; //功能码15
    TX_Frame[2] = (Coil_Address >> 8) & 0xFF; //线圈地址高字节
    TX_Frame[3] = Coil_Address & 0xFF; //线圈地址低字节
    TX_Frame[4] = (Num_Coils >> 8) & 0xFF; //线圈数量高字节
    TX_Frame[5] = Num_Coils & 0xFF; //线圈数量低字节
    crc = Modbus_CRC16(TX_Frame, 6); //计算CRC校验码
    TX_Frame[6] = crc & 0xFF; //CRC低字节
    TX_Frame[7] = (crc >> 8) & 0xFF; //CRC高字节

    Modbus_Send(TX_Frame, 8);
}

//16功能码，Modbus写多个保持寄存器
void Modbus_Slave_16(uint16_t Reg_Address, uint16_t Num_Regs, uint16_t *Reg_Values)
{
    uint8_t TX_Frame[8]; //根据需要调整缓冲区大小
    uint16_t crc;

    TX_Frame[0] = Modbus_Slave_ID; //Modbus RTU从站地址
    TX_Frame[1] = 0x10; //功能码16
    TX_Frame[2] = (Reg_Address >> 8) & 0xFF; //寄存器地址高字节
    TX_Frame[3] = Reg_Address & 0xFF; //寄存器地址低字节
    TX_Frame[4] = (Num_Regs >> 8) & 0xFF; //寄存器数量高字节
    TX_Frame[5] = Num_Regs & 0xFF; //寄存器数量低字节

    crc = Modbus_CRC16(TX_Frame, 6); //计算CRC校验码
    TX_Frame[6] = crc & 0xFF; //CRC低字节
    TX_Frame[7] = (crc >> 8) & 0xFF; //CRC高字节

    Modbus_Send(TX_Frame, 8);
}

//Modbus CRC16校验计算函数
uint16_t Modbus_CRC16(uint8_t *data, uint16_t length)
{
    uint16_t crc = 0xFFFF; //初始化CRC寄存器
    for (uint16_t i = 0; i < length; i++)
    {
        crc ^= data[i]; //将数据与CRC寄存器进行异或运算
        for (uint8_t j = 0; j < 8; j++)
        {
            if (crc & 0x0001) //检查最低位是否为1
            {
                crc >>= 1; //右移一位
                crc ^= 0xA001; //与多项式进行异或运算
            }
            else
            {
                crc >>= 1; //右移一位
            }
        }
    }
    return crc; //返回计算得到的CRC值
}
